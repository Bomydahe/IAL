/*
 * Binárny vyhľadávací strom — iteratívna varianta
 *
 * S využitím dátových typov zo súboru btree.h, zásobníkov zo súborov stack.h a
 * stack.c a pripravených kostier funkcií implementujte binárny vyhľadávací
 * strom bez použitia rekurzie.
 */

#include "../btree.h"
#include "stack.h"
#include <stdio.h>
#include <stdlib.h>

/*
 * Inicializácia stromu.
 *
 * Užívateľ musí zaistiť, že incializácia sa nebude opakovane volať nad
 * inicializovaným stromom. V opačnom prípade môže dôjsť k úniku pamäte (memory
 * leak). Keďže neinicializovaný ukazovateľ má nedefinovanú hodnotu, nie je
 * možné toto detegovať vo funkcii.
 */
void bst_init(bst_node_t **tree) {
  *tree = NULL;
}

/*
 * Nájdenie uzlu v strome.
 *
 * V prípade úspechu vráti funkcia hodnotu true a do premennej value zapíše
 * hodnotu daného uzlu. V opačnom prípade funckia vráti hodnotu false a premenná
 * value ostáva nezmenená.
 *
 * Funkciu implementujte iteratívne bez použitia vlastných pomocných funkcií.
 */
bool bst_search(bst_node_t *tree, char key, int *value) {

  
  bst_node_t *Next = tree;  

	while(Next && (Next)->key != key)
	{
		if(key < (Next)->key)
			Next = (Next)->left;
		else if (key > (Next)->key)
			Next = (Next)->right;
    else
      break;
	}

  if (Next){
    *value = (Next)->value;
    return true;
  }else 
    return false;
	
	
  
}

/*
 * Vloženie uzlu do stromu.
 *
 * Pokiaľ uzol so zadaným kľúčom v strome už existuje, nahraďte jeho hodnotu.
 * Inak vložte nový listový uzol.
 *
 * Výsledný strom musí spĺňať podmienku vyhľadávacieho stromu — ľavý podstrom
 * uzlu obsahuje iba menšie kľúče, pravý väčšie.
 *
 * Funkciu implementujte iteratívne bez použitia vlastných pomocných funkcií.
 */
void bst_insert(bst_node_t **tree, char key, int value) {
  
    bst_node_t *tmp = *tree;
    bst_node_t *parent = NULL;
    while(tmp)
    {
        parent = tmp;
        if(key < tmp->key)
        {
            tmp = tmp->left;
        }
        else if(key > tmp->key)
        {
            tmp = tmp->right;
        }
        else
        {
            tmp->value = value;
            return;
        }
    }
    bst_node_t *tmpN = malloc (sizeof(struct bst_node));
    if(tmpN)
    {
        tmpN->key = key;
        tmpN->value = value;
        tmpN->left = tmpN->right = NULL;
        if (!parent) 
        {
            *tree = tmpN;
        }
        else if (key < parent->key)
        {
            parent->left = tmpN;
        }
        else
        {
            parent->right = tmpN;
        }

    }
    return;

}

/*
 * Pomocná funkcia ktorá nahradí uzol najpravejším potomkom.
 *
 * Kľúč a hodnota uzlu target budú nahradené kľúčom a hodnotou najpravejšieho
 * uzlu podstromu tree. Najpravejší potomok bude odstránený. Funkcia korektne
 * uvoľní všetky alokované zdroje odstráneného uzlu.
 *
 * Funkcia predpokladá že hodnota tree nie je NULL.
 *
 * Táto pomocná funkcia bude využitá pri implementácii funkcie bst_delete.
 *
 * Funkciu implementujte iteratívne bez použitia vlastných pomocných funkcií.
 */
void bst_replace_by_rightmost(bst_node_t *target, bst_node_t **tree) {

  if(!(*tree)) 										
		return;	

  bst_node_t *rightmost = *tree;

  while (rightmost->right)    
    rightmost = rightmost->right;
  
  target->key = rightmost->key;
	target->value = rightmost->value;
   bst_delete(tree, rightmost->key);
}

/*
 * Odstránenie uzlu v strome.
 *
 * Pokiaľ uzol so zadaným kľúčom neexistuje, funkcia nič nerobí.
 * Pokiaľ má odstránený uzol jeden podstrom, zdedí ho otec odstráneného uzla.
 * Pokiaľ má odstránený uzol oba podstromy, je nahradený najpravejším uzlom
 * ľavého podstromu. Najpravejší uzol nemusí byť listom!
 * Funkcia korektne uvoľní všetky alokované zdroje odstráneného uzlu.
 *
 * Funkciu implementujte iteratívne pomocou bst_replace_by_rightmost a bez
 * použitia vlastných pomocných funkcií.
 */
void bst_delete(bst_node_t **tree, char key) {

    bst_node_t *tmp = *tree;
    bst_node_t *prt = *tree;
    while (tmp)
    {
        if(key < tmp->key)
        {
            prt = tmp;
            tmp = tmp->left;
        }
        else if(key > tmp->key)
        {
            prt = tmp;
            tmp = tmp->right;
        }
        else if(key == tmp->key)
        {
            if(!(tmp->left) && !(tmp->right))
            {
                if(tmp == prt)
                {
                    free(tmp);
                    (*tree) = NULL;
                    return;
                }
                if(prt->right == tmp) 
                {
                    free(tmp);
                    prt->right = NULL;
                    return;
                }
                else 
                {
                    free(tmp);
                    prt->left = NULL;
                    return;
                }
            }

            else if((tmp->left) && !(tmp->right))
            {
                bst_node_t *node;
                node = tmp->left;
                if(tmp == prt)
                {
                    free(tmp);
                    (*tree) = node;
                    return;
                }
                if(prt->right == tmp)
                {
                    free(tmp);
                    prt->right = node;
                }
                else
                {
                    free(tmp);
                    prt->left = node;
                }

                return;

            }
            else if(!(tmp->left) && (tmp->right))
            {
                bst_node_t *node;
                node = (tmp)->right;
                if(tmp == prt)
                {
                    free(tmp);
                    (*tree) = node;
                    return;
                }
                if(prt->right == tmp)
                {
                    free(tmp);
                    prt->right = node;
                }
                else
                {
                    free(tmp);
                    prt->left = node;
                }
                return;
            }
            else
            {
                bst_replace_by_rightmost(tmp, &(tmp->left));
                return;

            }
        }
    }
    	
}

/*
 * Zrušenie celého stromu.
 *
 * Po zrušení sa celý strom bude nachádzať v rovnakom stave ako po
 * inicializácii. Funkcia korektne uvoľní všetky alokované zdroje rušených
 * uzlov.
 *
 * Funkciu implementujte iteratívne pomocou zásobníku uzlov a bez použitia
 * vlastných pomocných funkcií.
 */
void bst_dispose(bst_node_t **tree) {

  	stack_bst_t tmp;
	stack_bst_init(&tmp);	
	
	do {		
		
		if(*tree == NULL) {				
			
			if(!stack_bst_empty(&tmp)) {
				*tree = stack_bst_top(&tmp);
				stack_bst_pop(&tmp);
			}
			
		} else {							
			
			if((*tree)->right != NULL) {	
				stack_bst_push(&tmp, (*tree)->right);
			}
			
			bst_node_t *toDelete = *tree;	
			*tree = (*tree)->left;	
			free(toDelete);					
			
		}
		
	} while((*tree != NULL) || (!stack_bst_empty(&tmp)));

	
	

}

/*
 * Pomocná funkcia pre iteratívny preorder.
 *
 * Prechádza po ľavej vetve k najľavejšiemu uzlu podstromu.
 * Nad spracovanými uzlami zavola bst_print_node a uloží ich do zásobníku uzlov.
 *
 * Funkciu implementujte iteratívne pomocou zásobníku uzlov a bez použitia
 * vlastných pomocných funkcií.
 */
void bst_leftmost_preorder(bst_node_t *tree, stack_bst_t *to_visit) {

  while(tree)
		{
			bst_print_node(tree);
			stack_bst_push(to_visit, tree);
			tree = tree->left;
		}
}

/*
 * Preorder prechod stromom.
 *
 * Pre aktuálne spracovávaný uzol nad ním zavolajte funkciu bst_print_node.
 *
 * Funkciu implementujte iteratívne pomocou funkcie bst_leftmost_preorder a
 * zásobníku uzlov bez použitia vlastných pomocných funkcií.
 */
void bst_preorder(bst_node_t *tree) {

  if(!tree) 
		return;		
	
	stack_bst_t stack;
	stack_bst_init(&stack);
  bst_node_t *tmp;

  bst_leftmost_preorder(tree, &stack);

	while(!stack_bst_empty(&stack))
	{
		tmp = stack_bst_top(&stack);
		stack_bst_pop(&stack);		
		if(tmp->right != NULL)	
		{
			bst_leftmost_preorder(tmp->right, &stack);	
		}
	}
}

/*
 * Pomocná funkcia pre iteratívny inorder.
 *
 * Prechádza po ľavej vetve k najľavejšiemu uzlu podstromu a ukladá uzly do
 * zásobníku uzlov.
 *
 * Funkciu implementujte iteratívne pomocou zásobníku uzlov a bez použitia
 * vlastných pomocných funkcií.
 */
void bst_leftmost_inorder(bst_node_t *tree, stack_bst_t *to_visit) {

  while (tree){

		stack_bst_push(to_visit, tree); 
		tree = tree->left; 
	}
}

/*
 * Inorder prechod stromom.
 *
 * Pre aktuálne spracovávaný uzol nad ním zavolajte funkciu bst_print_node.
 *
 * Funkciu implementujte iteratívne pomocou funkcie bst_leftmost_inorder a
 * zásobníku uzlov bez použitia vlastných pomocných funkcií.
 */
void bst_inorder(bst_node_t *tree) {

  stack_bst_t stack;
	stack_bst_init(&stack);

  bst_leftmost_inorder(tree, &stack);
	while (!stack_bst_empty(&stack)) 
	{
		tree = stack_bst_top(&stack);
		stack_bst_pop(&stack);
		bst_print_node(tree); 
		bst_leftmost_inorder(tree->right, &stack);
	}
}

/*
 * Pomocná funkcia pre iteratívny postorder.
 *
 * Prechádza po ľavej vetve k najľavejšiemu uzlu podstromu a ukladá uzly do
 * zásobníku uzlov. Do zásobníku bool hodnôt ukladá informáciu že uzol
 * bol navštívený prvý krát.
 *
 * Funkciu implementujte iteratívne pomocou zásobníkov uzlov a bool hodnôt a bez použitia
 * vlastných pomocných funkcií.
 */
void bst_leftmost_postorder(bst_node_t *tree, stack_bst_t *to_visit,
                            stack_bool_t *first_visit) {
  while (tree){

		stack_bst_push(to_visit, tree);
    stack_bool_push(first_visit, true); 
		tree = tree->left; 
	}
}

/*
 * Postorder prechod stromom.
 *
 * Pre aktuálne spracovávaný uzol nad ním zavolajte funkciu bst_print_node.
 *
 * Funkciu implementujte iteratívne pomocou funkcie bst_leftmost_postorder a
 * zásobníkov uzlov a bool hodnôt bez použitia vlastných pomocných funkcií.
 */
void bst_postorder(bst_node_t *tree) {

  	bool left;
	stack_bst_t Stack;
	stack_bool_t StackBool;
	stack_bst_init(&Stack);
	stack_bool_init(&StackBool);
	
	bst_node_t *Ptr = tree;
	
	bst_leftmost_postorder(Ptr, &Stack, &StackBool);
	
	while(!stack_bst_empty(&Stack)) {
		
		Ptr = stack_bst_top(&Stack);
		stack_bst_pop(&Stack);

		stack_bst_push(&Stack, Ptr);	
		
		left = stack_bool_top(&StackBool);
		stack_bool_pop(&StackBool);
		
		if(left) {			
			
			stack_bool_push(&StackBool, false);
			bst_leftmost_postorder(Ptr->right, &Stack, &StackBool);
			
		} else {			
			
			stack_bst_top(&Stack);
			stack_bst_pop(&Stack);	
			bst_print_node(Ptr);
			
		}
		
	}
}
